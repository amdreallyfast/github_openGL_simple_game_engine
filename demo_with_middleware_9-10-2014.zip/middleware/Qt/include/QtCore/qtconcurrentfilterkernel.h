#include "../../src/corelib/concurrent/qtconcurrentfilterkernel.h"
