#include "../../src/corelib/global/qlibraryinfo.h"
