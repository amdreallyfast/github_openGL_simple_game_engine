#include "../../src/corelib/statemachine/qeventtransition.h"
