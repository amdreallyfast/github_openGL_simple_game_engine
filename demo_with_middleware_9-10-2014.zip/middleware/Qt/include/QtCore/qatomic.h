#include "../../src/corelib/thread/qatomic.h"
