#include "../../src/corelib/arch/qatomic_arm.h"
