#include "../../src/corelib/arch/qatomic_avr32.h"
