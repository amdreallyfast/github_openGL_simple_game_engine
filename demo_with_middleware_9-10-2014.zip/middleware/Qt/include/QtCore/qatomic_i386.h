#include "../../src/corelib/arch/qatomic_i386.h"
