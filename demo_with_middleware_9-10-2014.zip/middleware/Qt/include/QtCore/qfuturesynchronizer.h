#include "../../src/corelib/concurrent/qfuturesynchronizer.h"
