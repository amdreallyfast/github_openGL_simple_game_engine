#include "../../src/corelib/global/qfeatures.h"
