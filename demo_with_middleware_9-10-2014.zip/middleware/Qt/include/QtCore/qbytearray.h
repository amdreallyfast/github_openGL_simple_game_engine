#include "../../src/corelib/tools/qbytearray.h"
