#include "../../src/corelib/tools/qcontiguouscache.h"
