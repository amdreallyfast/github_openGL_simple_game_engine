#include "../../src/corelib/tools/qsharedpointer.h"
