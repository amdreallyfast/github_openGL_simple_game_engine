#include "../../src/corelib/arch/qatomic_ia64.h"
