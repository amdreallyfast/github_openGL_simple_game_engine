#include "../../src/corelib/tools/qscopedpointer.h"
