#include "../../src/corelib/concurrent/qtconcurrentreducekernel.h"
