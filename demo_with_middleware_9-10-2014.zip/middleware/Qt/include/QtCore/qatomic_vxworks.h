#include "../../src/corelib/arch/qatomic_vxworks.h"
