#include "../../src/corelib/thread/qwaitcondition.h"
