#include "../../../src/corelib/kernel/qcore_symbian_p.h"
