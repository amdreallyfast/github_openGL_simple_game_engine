#include "../../../src/corelib/plugin/qelfparser_p.h"
