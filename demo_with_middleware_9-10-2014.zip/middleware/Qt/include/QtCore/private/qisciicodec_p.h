#include "../../../src/corelib/codecs/qisciicodec_p.h"
