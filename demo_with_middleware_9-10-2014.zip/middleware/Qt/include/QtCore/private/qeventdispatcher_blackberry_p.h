#include "../../../src/corelib/kernel/qeventdispatcher_blackberry_p.h"
