#include "../../../src/corelib/statemachine/qabstracttransition_p.h"
