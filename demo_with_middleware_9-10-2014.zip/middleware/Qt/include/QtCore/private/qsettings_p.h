#include "../../../src/corelib/io/qsettings_p.h"
