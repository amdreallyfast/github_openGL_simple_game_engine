#include "../../src/corelib/arch/qatomic_armv5.h"
