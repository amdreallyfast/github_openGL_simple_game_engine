#include "../../src/corelib/kernel/qtranslator.h"
