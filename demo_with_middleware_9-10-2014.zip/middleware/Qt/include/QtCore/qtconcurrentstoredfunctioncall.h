#include "../../src/corelib/concurrent/qtconcurrentstoredfunctioncall.h"
