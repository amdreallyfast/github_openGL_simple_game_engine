#include "../../src/corelib/tools/qlocale_blackberry.h"
