#include "../../src/corelib/arch/qatomic_sh4a.h"
