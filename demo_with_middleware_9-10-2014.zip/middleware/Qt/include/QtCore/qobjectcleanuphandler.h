#include "../../src/corelib/kernel/qobjectcleanuphandler.h"
