#include "../../src/corelib/arch/qatomic_parisc.h"
