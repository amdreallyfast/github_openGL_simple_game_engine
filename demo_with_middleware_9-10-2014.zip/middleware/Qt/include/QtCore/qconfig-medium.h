#include "../../src/corelib/global/qconfig-medium.h"
