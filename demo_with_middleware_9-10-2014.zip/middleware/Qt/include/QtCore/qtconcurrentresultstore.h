#include "../../src/corelib/concurrent/qtconcurrentresultstore.h"
