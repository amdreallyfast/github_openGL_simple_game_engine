#include "../../../src/gui/kernel/qcocoaapplication_mac_p.h"
