#include "../../../src/gui/widgets/qeffects_p.h"
