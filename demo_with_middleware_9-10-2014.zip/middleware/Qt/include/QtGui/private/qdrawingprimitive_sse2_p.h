#include "../../../src/gui/painting/qdrawingprimitive_sse2_p.h"
