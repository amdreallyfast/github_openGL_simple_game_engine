#include "../../../src/gui/styles/qcleanlooksstyle_p.h"
