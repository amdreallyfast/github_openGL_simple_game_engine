#include "../../../src/gui/kernel/qcocoapanel_mac_p.h"
