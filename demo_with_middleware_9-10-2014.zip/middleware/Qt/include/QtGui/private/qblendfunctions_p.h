#include "../../../src/gui/painting/qblendfunctions_p.h"
