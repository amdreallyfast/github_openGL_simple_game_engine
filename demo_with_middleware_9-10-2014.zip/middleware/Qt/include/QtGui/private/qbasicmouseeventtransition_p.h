#include "../../../src/gui/statemachine/qbasicmouseeventtransition_p.h"
