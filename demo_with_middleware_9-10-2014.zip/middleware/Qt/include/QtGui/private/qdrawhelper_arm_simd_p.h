#include "../../../src/gui/painting/qdrawhelper_arm_simd_p.h"
