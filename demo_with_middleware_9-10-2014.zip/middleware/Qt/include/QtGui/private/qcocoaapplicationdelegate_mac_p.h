#include "../../../src/gui/kernel/qcocoaapplicationdelegate_mac_p.h"
