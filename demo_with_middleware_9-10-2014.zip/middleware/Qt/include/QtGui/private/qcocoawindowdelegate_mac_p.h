#include "../../../src/gui/kernel/qcocoawindowdelegate_mac_p.h"
